﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace jokesweb.Data.Migrations
{
    public partial class test : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "JokeAnswer",
                table: "joke");

            migrationBuilder.DropColumn(
                name: "JokeQuestion",
                table: "joke");

            migrationBuilder.AddColumn<string>(
                name: "Ting1",
                table: "joke",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Ting2",
                table: "joke",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Ting1",
                table: "joke");

            migrationBuilder.DropColumn(
                name: "Ting2",
                table: "joke");

            migrationBuilder.AddColumn<int>(
                name: "JokeAnswer",
                table: "joke",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "JokeQuestion",
                table: "joke",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
