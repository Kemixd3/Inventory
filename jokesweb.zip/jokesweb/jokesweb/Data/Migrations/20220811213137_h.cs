﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace jokesweb.Data.Migrations
{
    public partial class h : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "JokeQuestion",
                table: "joke");

            migrationBuilder.DropColumn(
                name: "JokeAnswer",
                table: "joke");

            migrationBuilder.AddColumn<string>(
                name: "JokeAnswer",
                table: "joke",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "JokeQuestion",
                table: "joke",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "JokeAnswer",
                table: "joke");

            migrationBuilder.DropColumn(
                name: "JokeQuestion",
                table: "joke");

            migrationBuilder.AddColumn<string>(
                name: "JokeQuestion",
                table: "joke",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "JokeAnswer",
                table: "joke",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
