﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace jokesweb.Models
{
    public class joke
    {

        public int Id { get; set; }
        public string JokeQuestion { get; set; }
        public string JokeAnswer { get; set; }
        public joke()
        {

        }


    }
    public class IndexViewModel2
    {

    public joke joke { get; set; }

    public List<joke> jokes { get; set; }
}

}
