﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace jokesweb.Models
{
    public class ViewIndex
    {
		public class User
		{
	public string Username { get; set; }
		public string Name { get; set; }
		public string LastName { get; set; }
	}
	public class IndexViewModel
	{
	public User User { get; set; }

	public List<User> FriendList { get; set; }
}
    }

}
